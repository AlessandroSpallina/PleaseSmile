//ciao
#include <stm32f10x.h>
#include <stm32f10x_rcc.h>
#include <stm32f10x_gpio.h>
#include <stm32f10x_usart.h>
#include <misc.h>

void Delay(uint32_t nTime);
void change_pause();

static int pause = 1000;
static int variation = 0;


#define QUEUE_SIZE 16

typedef struct Queue {
  uint16_t pRD, pWR;
  uint8_t  q[QUEUE_SIZE];
} TQueue;

TQueue UART2_RXq;

static int Enqueue(TQueue *q, uint8_t data);
static int Dequeue(TQueue *q, uint8_t *data);

int PutChar(char c);
int GetChar(void);


int main(void)
{

    // Enable bus A and C and Usart2
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);

    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_StructInit(&GPIO_InitStructure);

    // PA5 (LED)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // PA6 (LED)---7
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // PA7 (LED)---7
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // PA8 (LED)---7
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // PC13 (Button)
    GPIO_StructInit(&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOC, &GPIO_InitStructure);


  // Initialize USART2_RX
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOA, &GPIO_InitStructure);


  // Configure NVIC
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);

  NVIC_InitTypeDef NVIC_InitStructure;
  NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);


  // Initialize USART structure
  USART_InitTypeDef USART_InitStructure;
  USART_StructInit(&USART_InitStructure);

  USART_InitStructure.USART_BaudRate = 115200; // 9600;
  /*
  USART_InitStructure.USART_BaudRate = 115200;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  */
  USART_InitStructure.USART_Mode = USART_Mode_Rx;
  USART_Init(USART2, &USART_InitStructure);
  USART_Cmd(USART2, ENABLE);


  USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);

  // Init circular buffers
  UART2_RXq.pRD = 0;
  UART2_RXq.pWR = 0;


  int received_char;

    if (SysTick_Config(SystemCoreClock / 1000)) while (1);

    static int ledval = 0;

    while (1)
   {

    received_char = GetChar();

      if(received_char ==0 /*<10*/){
        GPIO_WriteBit(GPIOA, GPIO_Pin_5, (ledval) ? Bit_SET : Bit_RESET);
        GPIO_WriteBit(GPIOA, GPIO_Pin_6, (ledval) ? Bit_SET : Bit_RESET);
        GPIO_WriteBit(GPIOA, GPIO_Pin_7, (ledval) ? Bit_SET : Bit_RESET);
        GPIO_WriteBit(GPIOA, GPIO_Pin_8, (ledval) ? Bit_SET : Bit_RESET);
        Delay(pause);
        ledval = 1 - ledval;
      }
    /*  else if(received_char>10 && received_char<20){
        GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_RESET);
        GPIO_WriteBit(GPIOA, GPIO_Pin_6, (ledval) ? Bit_SET : Bit_RESET);
        GPIO_WriteBit(GPIOA, GPIO_Pin_7, (ledval) ? Bit_SET : Bit_RESET);
        GPIO_WriteBit(GPIOA, GPIO_Pin_8, (ledval) ? Bit_SET : Bit_RESET);
        Delay(pause);
        ledval = 1 - ledval;
      }
      else if(received_char>20 && received_char<30){
        GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_RESET);
        GPIO_WriteBit(GPIOA, GPIO_Pin_6, Bit_RESET);
        GPIO_WriteBit(GPIOA, GPIO_Pin_7, (ledval) ? Bit_SET : Bit_RESET);
        GPIO_WriteBit(GPIOA, GPIO_Pin_8, (ledval) ? Bit_SET : Bit_RESET);
        Delay(pause);
        ledval = 1 - ledval;
      }
      else if(received_char>30 && received_char<40){
        GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_RESET);
        GPIO_WriteBit(GPIOA, GPIO_Pin_6, Bit_RESET);
        GPIO_WriteBit(GPIOA, GPIO_Pin_7, Bit_RESET);
        GPIO_WriteBit(GPIOA, GPIO_Pin_8, (ledval) ? Bit_SET : Bit_RESET);
        Delay(pause);
        ledval = 1 - ledval;
      }
      else{
        GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_RESET);
        GPIO_WriteBit(GPIOA, GPIO_Pin_6, Bit_RESET);
        GPIO_WriteBit(GPIOA, GPIO_Pin_7, Bit_RESET);
        GPIO_WriteBit(GPIOA, GPIO_Pin_8, Bit_RESET);
      }
	*/
   }
}


int RxOverflow = 0;
void USART2_IRQHandler(void)
{
  if (USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
  {
    uint8_t data;

    // buffer the data (or toss it if there's no room
    data = USART_ReceiveData(USART2) & 0xff;

    if (!Enqueue(&UART2_RXq, data))
      RxOverflow = 1;
  }
}

int GetChar(void)
{
  uint8_t data;

  while (!Dequeue(&UART2_RXq, &data)) ;

  return data;
}


static int QueueFull(TQueue *q)
{
  return (((q->pWR + 1) % QUEUE_SIZE) == q->pRD);
}

static int QueueEmpty(TQueue *q)
{
  return (q->pWR == q->pRD);
}


static int Enqueue(TQueue *q, uint8_t data)
{
  if (QueueFull(q))
    return 0;

  q->q[q->pWR] = data;
  q->pWR = ((q->pWR + 1) == QUEUE_SIZE) ? 0 : q->pWR + 1;

  return 1;
}

static int Dequeue(TQueue *q, uint8_t *data)
{
  if (QueueEmpty(q))
    return 0;

  *data = q->q[q->pRD];
  q->pRD = ((q->pRD + 1) == QUEUE_SIZE) ? 0 : q->pRD + 1;

  return 1;
}



void change_pause()
{
    Delay(500);
    pause = pause/2;
}

static __IO uint32_t TimingDelay;

void Delay(uint32_t nTime){
    TimingDelay = nTime; while(TimingDelay != 0);
}

void SysTick_Handler(void){
    if (TimingDelay != 0x00)
    TimingDelay--;
}


#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
/* Infinite loop */
/* Use GDB to find out why we're here */ while (1);
}
#endif
